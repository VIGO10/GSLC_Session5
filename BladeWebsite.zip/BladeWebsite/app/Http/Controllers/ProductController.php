<?php

namespace App\Http\Controllers;

use App\Models\Product;
use Illuminate\Http\Request;

class ProductController extends Controller
{
    public function index(){

        //Ambil Data
        //Eloquent ORM
        $data = Product::all(); // SELECT * FROM products


        //Kirim Data
        return view('home', compact('data'));
    }
}
