<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="/css/main.css">
</head>
<body>


<?php $__env->startSection('title', 'Home'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="container d-flex">
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="card" style="width: 18rem;">
                <img src=<?php echo e($d->image_path); ?> class="card-img-top" alt="...">
                <div class="card-body">
                    <h5 class="card-title"><?php echo e($d->name); ?></h5>
                    <p class="card-text"><?php echo e($d->desc); ?></p>
                    <p class="card-text"><?php echo e($d->price); ?></p>

                    <?php if($d->type === "drink"): ?>
                        <span class="badge text-danger"><?php echo e($d->type); ?></span>
                    <?php else: ?>
                        <span class="badge text-primary"><?php echo e($d->type); ?></span>
                    <?php endif; ?>

                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>

<?php $__env->stopSection(); ?>
</body>
</html>
<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\XAMPP\htdocs\BladeWebsite\resources\views/home.blade.php ENDPATH**/ ?>