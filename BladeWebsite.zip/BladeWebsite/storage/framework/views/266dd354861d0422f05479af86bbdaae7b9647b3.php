<footer class="footer">
  <p class="footer_copyright">
    <h1>&copy;2022 Erafone Bulusaraung. All rights reserved.</h1>
  </p>
</footer><?php /**PATH D:\XAMPP\htdocs\session 2\resources\views/footer.blade.php ENDPATH**/ ?>