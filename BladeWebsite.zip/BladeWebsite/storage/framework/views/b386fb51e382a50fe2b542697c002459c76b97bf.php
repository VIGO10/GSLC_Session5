<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="/css/header.css">
</head>
<body>
    <header class="header">
        <div class="header_left">
            <div class="header_home">Home Log In</div>
        </div>
        <div class="header_about">About</div>
    </header>
</body>
</html><?php /**PATH D:\XAMPP\htdocs\BladeWebsite\resources\views/header.blade.php ENDPATH**/ ?>