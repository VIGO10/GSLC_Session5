<?php

namespace Database\Seeders;

use App\Models\Product;
use Illuminate\Database\Seeder;

class ProductSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        Product::query()->insert(
            [
                [
                    "id" => 1,
                    "name" => "Iphone 14 Pro",
                    "type" => "iOS",
                    "desc" => "Didesain untuk selalu kokoh. Dengan Ceramic Shield, lebih tangguh dari kaca ponsel pintar mana pun. Tahan air.",
                    "price" => 26999999,
                    "image_path" => "https://fdn2.gsmarena.com/vv/bigpic/apple-iphone-14-pro.jpg"
                ],
                [
                    "id" => 2,
                    "name" => "Xiaomi 11T Pro",
                    "type" => "Android",
                    "desc" => "Kamera ultra-wide angle 120° FOV Menangkap momen hidup lebih besar dan lebih lebar.",
                    "price" => 10999999,
                    "image_path" => "https://fdn2.gsmarena.com/vv/bigpic/xiaomi-11t-pro.jpg"
                ],
                [
                    "id" => 3,
                    "name" => "ROG Phone 6",
                    "type" => "Android",
                    "desc" => "The latest incarnation of world-beating gaming phone. It harnesses the brute gaming power of the latest Qualcomm® Snapdragon® 8+ Gen 1 Mobile Platform",
                    "price" => 9839000,
                    "image_path" => "https://fdn2.gsmarena.com/vv/bigpic/asus-rog-phone6-pro.jpg"
                ],
            ]
        );
    }
}
