<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

/*
Route::RequestMethod('path'. callbackFunction);

Request Method:
1. GET          -> Menampilkan Page
2. POST         -> Form Submit
3. UPDATE/PUT   -> Update Data
4. DELETE       -> Delete Data
*/

Route::get('/phone', [\App\Http\Controllers\ProductController::class, 'index']);
