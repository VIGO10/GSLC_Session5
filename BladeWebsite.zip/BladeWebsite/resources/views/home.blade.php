<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="/css/main.css">
</head>
<body>
@extends('main')

@section('title', 'Home')

@section('content')
    <div class="container-fluid">
        <div class="container d-flex">
            @foreach($data as $d)
            <div class="card" style="width: 18rem;">
                <img src={{$d->image_path}} class="card-img-top" alt="...">
                <div class="card-body">
                    <h5 class="card-title">{{$d->name}}</h5>
                    <p class="card-text">{{$d->desc}}</p>
                    <p class="card-text">{{$d->price}}</p>

                    @if($d->type === "drink")
                        <span class="badge text-danger">{{$d->type}}</span>
                    @else
                        <span class="badge text-primary">{{$d->type}}</span>
                    @endif

                </div>
            </div>
            @endforeach
        </div>
    </div>

@endsection
</body>
</html>